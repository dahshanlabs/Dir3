# Dir3 — 24-Hour Execution Checklist

> Print this. Tape it next to your monitor. Cross off as you go.
> Times are Riyadh local. Buildathon starts Saturday May 2 2026 at 3:00 PM Riyadh.

---

## PRE-LAUNCH (do TODAY, before 3 PM Riyadh)

**Operations setup**
- [ ] Replit Pro account ready (verify Agent access)
- [ ] GitHub account ready, create empty repo `dir3` or `dir3-platform`
- [ ] Domain registered: `dir3.ai` or `getdir3.com` or `trydir3.com`
- [ ] Anthropic API key ($100+ credits)
- [ ] OpenAI API key ($100+ credits)
- [ ] Google AI / Gemini API key ($50+ credits)
- [ ] Resend account (free tier, for magic links)
- [ ] Twitter/X account ready (Dir3 handle if available)
- [ ] LinkedIn personal page polished
- [ ] Facebook post draft ready

**Files prepared**
- [ ] All 14 files in this package downloaded to local
- [ ] `00-START-HERE.md` reviewed
- [ ] `01-REPLIT-AGENT-PROMPT.md` ready to paste

**Mental prep**
- [ ] Decide: solo or team? If team, roles assigned
- [ ] Sleep 8 hours night before
- [ ] Coffee + water + snacks ready
- [ ] Notify family: 24 hours focused work
- [ ] Phone on Do Not Disturb except for emergencies

---

## H+0 → H+1 (3:00 PM → 4:00 PM): SETUP

- [ ] Open Replit, create new project
- [ ] Initialize monorepo: `pnpm init`, set up Turborepo
- [ ] Create directory structure per `03-ARCHITECTURE.md`
- [ ] Setup TypeScript with strict mode
- [ ] Install base deps: next, react, hono, drizzle-orm, postgres, zod
- [ ] Connect Replit Postgres, get DATABASE_URL
- [ ] Run `04-database-schema.sql` against the DB
- [ ] Verify schema with simple query
- [ ] Push first commit to GitHub: "feat: initial monorepo setup"

**Checkpoint:** DB exists, repo committed, dev server runs.

---

## H+1 → H+3 (4:00 PM → 6:00 PM): CORE ENGINE + AUTH

- [ ] Build `packages/core-engine` skeleton
- [ ] Implement `detectPromptInjection()` — Layer 1 regex
- [ ] Implement `detectPII()` — Saudi-specific (national ID, IBAN, Iqama)
- [ ] Implement `arabic-utils.ts`: stripDiacritics, normalizeKashida, detectScript
- [ ] Implement `analyze()` orchestrator
- [ ] Load attack library JSON into `packages/attack-library`
- [ ] Setup Better Auth with magic link via Resend
- [ ] Create `/api/auth/*` routes
- [ ] Test: send yourself a magic link, log in

**Checkpoint:** Detection engine returns valid output. Auth works end-to-end.

---

## H+3 → H+8 (6:00 PM → 11:00 PM): PLAYGROUND

- [ ] Build `/playground` page UI (left pane: input, right pane: results)
- [ ] BYOK key input with localStorage encryption
- [ ] Multi-model selector
- [ ] Attack category multi-select
- [ ] `POST /api/playground/run` with SSE streaming
- [ ] LLM client wrappers for Anthropic, OpenAI, Google
- [ ] Judge LLM call (use `06-SYSTEM-PROMPTS.md` Attack Judge prompt)
- [ ] Hardness Score calculation
- [ ] Per-attack result display with explanations
- [ ] Aggregate score per model
- [ ] Comparison table when multiple models selected
- [ ] Save run to DB, generate share_id
- [ ] Public share page: `/playground/r/[shareId]`
- [ ] Bilingual UI (RTL toggle in header)

**Checkpoint:** End-to-end playground run works. Real attacks against real models. Shareable URL produces same data.

**SAVE POINT:** Commit, push, create deployment snapshot.

---

## H+8 → H+13 (11:00 PM → 4:00 AM): PROXY + DASHBOARD

- [ ] Build `apps/api` Hono app
- [ ] `POST /v1/chat/completions` (OpenAI-compatible)
- [ ] `POST /v1/messages` (Anthropic-compatible)
- [ ] API key auth middleware
- [ ] Rate limiting middleware
- [ ] Pre-flight detection (use core-engine)
- [ ] Upstream forwarding adapters
- [ ] Post-flight detection on responses
- [ ] PII redaction logic
- [ ] Audit log writer (PII-redacted version)
- [ ] `dir3_metadata` field in responses
- [ ] Streaming support (SSE passthrough)
- [ ] `/dashboard` UI: API keys list, usage charts, recent blocks
- [ ] Create/revoke API key flow
- [ ] Per-key configuration UI

**Checkpoint:** A real customer can sign up, get API key, swap base URL, and have their LLM calls proxied with detection.

**SAVE POINT:** Commit, deploy preview, test end-to-end with curl.

---

## H+13 → H+17 (4:00 AM → 8:00 AM): COMPLIANCE SCANNER

> ⚠️ Energy will be lowest here. Coffee. 15-min break OK.

- [ ] `/scanner` page UI
- [ ] Upload widget (text paste, JSON file, PDF privacy policy)
- [ ] `POST /api/scanner/run`
- [ ] Load `08-pdpl-articles.json` and `09-nca-ecc-controls.json`
- [ ] PDPL evaluator (use system prompt from `06-SYSTEM-PROMPTS.md`)
- [ ] NCA ECC evaluator
- [ ] Aggregate scoring logic
- [ ] Findings list UI with severity, citations, remediation
- [ ] PDF report generator with @react-pdf/renderer (bilingual)
- [ ] Save scan to DB, share_id
- [ ] Test with 3 sample system prompts (banking, healthcare, gov)

**Checkpoint:** Upload a system prompt, get a real PDPL findings report with citations.

---

## H+17 → H+20 (8:00 AM → 11:00 AM): SHIELD + LEADERBOARD + CLI

> Energy returning. Visible progress. Push hard.

**Shield Generator (1 hour)**
- [ ] `/shield` page UI
- [ ] Hardening level selector (light/standard/paranoid)
- [ ] Domain selector
- [ ] `POST /api/shield/generate` (use Shield system prompt)
- [ ] Diff view of original vs hardened
- [ ] Techniques applied list
- [ ] Save shield_generation, share_id

**Leaderboard (1 hour)**
- [ ] `/leaderboard` public page
- [ ] Initial leaderboard run: execute attack library against top 5 models
- [ ] Save to `leaderboard_runs` table
- [ ] Display table with overall + per-category scores
- [ ] Per-model detail page
- [ ] Note: daily cron can come post-launch; manual run for v1

**CLI (1 hour)**
- [ ] `packages/cli` setup
- [ ] `bin.ts` entry with shebang
- [ ] Commands: test, scan, shield, check
- [ ] Pretty terminal output (chalk + ora)
- [ ] `--json` flag
- [ ] `package.json` with bin field
- [ ] Local test: `node dist/bin.js test ./prompt.txt`
- [ ] (Skip npm publish until after deploy — do it in H+22)

**Checkpoint:** All 6 products are working in some form, even if rough.

---

## H+20 → H+22 (11:00 AM → 1:00 PM): POLISH

- [ ] Bilingual review every page (Arabic + English)
- [ ] Mobile responsive check on iPhone simulator
- [ ] Loading states everywhere
- [ ] Error states everywhere
- [ ] Empty states (no data yet)
- [ ] Landing page using `10-LANDING-COPY.md`
- [ ] SEO meta tags + OG image (use Vercel OG or simple Tailwind component)
- [ ] Add favicon
- [ ] Add `robots.txt` and `sitemap.xml`
- [ ] Test signup flow end-to-end
- [ ] Test playground share URL
- [ ] Lighthouse score check (>80 for performance, >95 for accessibility)
- [ ] Fix any critical bugs (skip non-critical)

---

## H+22 → H+24 (1:00 PM → 3:00 PM): SHIP

> Final stretch. No new features. Only deploy + announce.

**Deploy (30 min)**
- [ ] Production env vars set in Replit
- [ ] Deploy to Replit Reserved VM
- [ ] Custom domain pointed
- [ ] HTTPS verified
- [ ] Test all routes in production
- [ ] Test signup → playground → result share in production

**Open source push (15 min)**
- [ ] Push to GitHub (open-source pieces only)
- [ ] Add `13-README.md` content as repo README
- [ ] Add LICENSE file (Apache 2.0)
- [ ] Add CONTRIBUTING.md
- [ ] Tag v1.0.0 release

**npm publish (15 min)**
- [ ] Build CLI: `pnpm --filter cli build`
- [ ] `cd packages/cli && npm publish` (you may need to login first)
- [ ] Verify: `npx dir3 --version`

**Documentation (15 min)**
- [ ] Quickstart for Playground
- [ ] Quickstart for Proxy (with curl example)
- [ ] Quickstart for CLI

**Launch (45 min)**
- [ ] Twitter/X thread (use templates in `11-PITCH-DEMO.md`)
- [ ] LinkedIn post
- [ ] Hacker News submission ("Show HN")
- [ ] Reddit r/MachineLearning post
- [ ] Product Hunt schedule (or launch immediately)
- [ ] Buildathon submission form
- [ ] Tweet at @Replit announcing
- [ ] Email outreach: top 5 Saudi banks (templates in 11)
- [ ] Email outreach: 5 Arabic AI community contacts

**Final check**
- [ ] Take screenshots of working product (for portfolio)
- [ ] Record 30-second demo video (Loom or QuickTime)
- [ ] Save backup: GitHub repo + Replit snapshot + DB dump

---

## POST-LAUNCH (next 24 hours, after sleep)

- [ ] Sleep 8+ hours
- [ ] Respond to all comments on social posts
- [ ] Answer all Hacker News / Reddit questions in detail
- [ ] Reach out to anyone who DMs
- [ ] Schedule customer discovery calls with anyone interested
- [ ] Open GitHub issues for v2 features
- [ ] Write a launch retrospective blog post

---

## EMERGENCY PLAN (if things go wrong)

### If Replit Agent freezes / loses context
- Restart conversation with fresh prompt from `01-REPLIT-AGENT-PROMPT.md`
- Re-attach the relevant files
- Tell it explicitly which Phase to resume

### If Postgres dies
- `pg_dump` was being taken hourly per the plan → restore from backup
- If totally lost: deploy Postgres on Railway or Neon as fallback (5 min)

### If API costs spiral
- Check token usage per model
- Cap max_tokens on judge calls to 500
- Use Claude Haiku 4.5 instead of Sonnet for non-critical judges
- Reduce attack count per run from 150 to 50 if needed

### If you're behind schedule at H+15
- Cut: Leaderboard daily cron (manual run only)
- Cut: CLI publish to npm (post-launch)
- Cut: Shield Generator (just have placeholder + waitlist)
- Keep: Playground, Proxy, Scanner — these are the value prop

### If you're behind schedule at H+20
- Cut to bare minimum: Playground only + landing + waitlist for everything else
- Mark Proxy/Scanner/Shield as "Coming Soon"
- Better to ship 1 polished product than 6 broken ones

### If you're way behind at H+23
- Just ship the landing page + Playground
- Tweet anyway. Saying "I tried" is better than not shipping.
- v1 can ship next weekend with the rest.

---

## CRITERIA FOR V1 SUCCESS

**Minimum viable launch:**
- [ ] Landing page loads in production
- [ ] At least 1 product works end-to-end (Playground is the priority)
- [ ] GitHub repo is public
- [ ] Tweet thread is posted
- [ ] Buildathon submission is in

**Strong launch:**
- [ ] All 6 products work in some form
- [ ] CLI on npm
- [ ] HN front page or 50+ Twitter likes
- [ ] 1 inbound interest email

**Dream launch:**
- [ ] All of the above
- [ ] 3+ Saudi enterprises asking for pilot
- [ ] HuggingFace or Anthropic team notices
- [ ] Press inquiry (Wamda, MENABytes)

---

**Remember:** ship beats perfect. Done is the new clean.

**يلا، شغل! 🚀**
