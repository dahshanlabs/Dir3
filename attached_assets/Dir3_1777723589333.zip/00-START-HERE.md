# Dir3 / درع — Production Build Package

> **Built for:** Replit 10 Buildathon, May 2 2026, 3 PM Riyadh start
> **Goal:** Ship complete production-ready Arabic-native AI guardrails platform in 24 hours

---

## What's In This Package (read in order)

| # | File | Purpose | When to use |
|---|------|---------|-------------|
| 00 | `00-START-HERE.md` | This file. Master index | First |
| 01 | `01-REPLIT-AGENT-PROMPT.md` | The mega-prompt to paste into Replit Agent at hour 0 | At launch |
| 02 | `02-PRD-FULL.md` | Complete product requirements document | Reference |
| 03 | `03-ARCHITECTURE.md` | Tech stack, monorepo structure, deployment | Hour 0–3 |
| 04 | `04-database-schema.sql` | Complete Postgres schema, ready to run | Hour 0–3 |
| 05 | `05-API-SPEC.md` | All API endpoints with contracts | Hour 3–13 |
| 06 | `06-SYSTEM-PROMPTS.md` | Every LLM system prompt for every component | Throughout |
| 07 | `07-attack-library.json` | 300+ attacks ready to import | Hour 3–8 |
| 08 | `08-pdpl-articles.json` | PDPL articles + mapping rules | Hour 13–17 |
| 09 | `09-nca-ecc-controls.json` | NCA ECC-2:2024 controls relevant to AI | Hour 13–17 |
| 10 | `10-LANDING-COPY.md` | Bilingual landing page copy (AR + EN) | Hour 17–22 |
| 11 | `11-PITCH-DEMO.md` | Buildathon submission text + demo script | Hour 22–24 |
| 12 | `12-CHECKLIST.md` | Hour-by-hour execution checklist | Throughout |
| 13 | `13-README.md` | GitHub README for the open-source pieces | Hour 22–24 |

---

## The 6 Products Being Built

1. **Dir3 Playground** — public attack testing UI (viral, demo-friendly)
2. **Dir3 Proxy** — drop-in API replacement with guardrails (the money piece)
3. **Dir3 Compliance Scanner** — PDPL/NCA gap analysis (enterprise piece)
4. **Dir3 Shield Generator** — auto-hardens system prompts
5. **Dir3 Leaderboard** — public Arabic Safety Index for all major LLMs
6. **Dir3 CLI** — `npx dir3 test` (developer love + GitHub stars)

All share the same **core detection engine** (built first, hour 0–3).

---

## Critical Decisions Already Made

- **Bilingual:** Arabic + English everywhere (UI, docs, reports)
- **Open-core:** core engine + partial attack library = open source. Proxy/Scanner/Dashboard = closed SaaS.
- **BYOK:** users bring their own LLM API keys. We never proxy our own keys.
- **Public launch as Dir3 / درع:** brand goes live with the buildathon
- **No PDPL deep features at launch:** scaffold + waitlist only; full PDPL engine ships post-buildathon

---

## What You Must Have Ready Before 3 PM Riyadh

- [ ] GitHub account + empty repo created (name: `dir3` or `dir3-platform`)
- [ ] Anthropic API key (for testing + comparison feature)
- [ ] OpenAI API key (for comparison feature)
- [ ] Google AI / Gemini API key (for comparison feature)
- [ ] Domain registered: `dir3.ai` if available, fallback `getdir3.com` or `trydir3.com`
- [ ] Replit Pro session ready (use the free Agent Day for compute, but have backup credits)
- [ ] Twitter/X + LinkedIn drafts ready (templates in `11-PITCH-DEMO.md`)
- [ ] Discord/Slack notification webhook for buildathon updates

---

## Risk Mitigation

| Risk | Mitigation |
|------|-----------|
| Replit Agent gets stuck on a feature | Skip it. The PRD is ranked priority 1–6. Cut 5 and 6 first. |
| Postgres crashes under load | Hourly `pg_dump` backup to GitHub via cron |
| Servers slow during free Agent day | Pre-write all prompts, run in parallel sessions if possible |
| Run out of time | Ship Playground only. It's the viral demo. The rest can be marked "Coming Soon" |
| Branding burnout | If shipped feels embarrassing, deploy under codename, keep `dir3.ai` for v2 launch |

---

## Hour-by-Hour Plan (summary, see 12-CHECKLIST.md for detail)

```
00:00–03:00  Foundation: monorepo, DB, auth, core engine
03:00–08:00  Playground (Attack testing UI + comparison)
08:00–13:00  Proxy API (drop-in replacement) + dashboard
13:00–17:00  Compliance Scanner (lite) + PDPL waitlist
17:00–20:00  Shield Generator + Leaderboard + CLI
20:00–22:00  Polish, bilingual review, docs
22:00–24:00  Deploy, GitHub push, launch tweets, buildathon submission
```

---

## When You Hit a Wall

1. Look at the PRD priority list. Cut from the bottom.
2. Use the system prompts in `06-SYSTEM-PROMPTS.md` verbatim — they're tuned.
3. The attack library is the moat. Don't cut it. Even if the UI is rough, the data is the differentiation.
4. Last resort: ship landing page + Playground only. Everything else as "Join waitlist."

---

## Post-Launch (Hour 24+)

- Tweet thread (template in 11-PITCH-DEMO.md)
- Submit to Replit 10 Buildathon
- Email Arabic AI/security communities (list in 11-PITCH-DEMO.md)
- Open Issues on GitHub for v2 features
- Schedule customer discovery calls with 5 Saudi banks/telcos

---

**You got this. ابدأ. 🚀**
