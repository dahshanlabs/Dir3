# Dir3 — Bilingual Landing Page Copy

> Complete copy for the marketing site. Designed for production use — every word is finalized.
> Implementation: paste into `apps/web/messages/ar.json` and `apps/web/messages/en.json`.

---

## SECTION 1: HERO

### English
**Headline:** The First Arabic-Native AI Security Platform  
**Subheadline:** Runtime guardrails, red-team testing, and PDPL/NCA compliance — built for the Saudi Arabian market.  
**CTA Primary:** Try Playground Free →  
**CTA Secondary:** Read Docs

**Trust line:** _Built for banks, telcos, healthtech, and government entities operating under PDPL and NCA ECC._

### Arabic
**العنوان الرئيسي:** أول منصة أمن ذكاء اصطناعي عربية بالكامل  
**العنوان الفرعي:** حماية فورية، واختبارات اختراق، والتزام بنظام حماية البيانات الشخصية وضوابط الأمن السيبراني — مبنية للسوق السعودي.  
**الزر الرئيسي:** جرّب Playground مجاناً ←  
**الزر الثانوي:** الوثائق

**سطر الثقة:** _مبنية للبنوك وشركات الاتصالات والصحة الرقمية والجهات الحكومية العاملة وفق نظام PDPL وضوابط NCA._

---

## SECTION 2: PROBLEM STATEMENT

### English
**Heading:** Existing AI Security Tools Were Built for English  
**Body:** Lakera, Promptfoo, Garak, NeMo Guardrails — they all share one blind spot. They don't speak Arabic. They miss diacritic injection. They can't recognize religious authority spoofing. They have no idea what PDPL or NCA ECC require. The Saudi market needs more than a translation layer. It needs a tool built from the ground up for Arabic and Saudi regulations.

### Arabic
**العنوان:** أدوات أمن AI الحالية مبنية للإنجليزية  
**النص:** Lakera، Promptfoo، Garak، NeMo Guardrails — كلها تشترك في نقطة عمياء واحدة. ما تفهم العربية. تتجاوز هجمات التشكيل. ما تعرف انتحال السلطة الدينية. ولا فكرة عندها عن متطلبات PDPL أو NCA. السوق السعودي يحتاج أكثر من طبقة ترجمة. يحتاج أداة مبنية من الجذور للعربية والأنظمة السعودية.

---

## SECTION 3: PRODUCTS GRID

### Heading EN: One Platform. Six Products. All Bilingual.
### العنوان: منصة واحدة. ست منتجات. كلها بالعربية والإنجليزية.

### Product 1: Playground

**EN — Title:** Test Any LLM Against 150+ Arabic Attacks  
**EN — Description:** Paste your system prompt. Pick your models. Run our attack library. Get a Hardness Score in minutes. Includes attacks no other tool has — diacritic injection, kashida steganography, religious authority spoofing.  
**EN — CTA:** Open Playground →

**AR — العنوان:** اختبر أي نموذج ضد ١٥٠+ هجوم عربي  
**AR — الوصف:** الصق system prompt. اختر النماذج. شغّل مكتبة الهجمات. احصل على Hardness Score في دقائق. يشمل هجمات ما عند أحد ثانٍ — التشكيل، الكشيدة، انتحال السلطة الدينية.  
**AR — الزر:** افتح Playground ←

### Product 2: Proxy

**EN — Title:** Drop-in API Replacement with Guardrails  
**EN — Description:** Change one line of code. Get prompt-injection blocking, PII redaction, audit logs, and PDPL-ready compliance — across OpenAI, Anthropic, Google, and any custom LLM.  
**EN — CTA:** Read API Docs →

**AR — العنوان:** بديل API مع طبقة حماية  
**AR — الوصف:** غيّر سطر واحد من الكود. احصل على حماية ضد حقن التعليمات، تنقيح PII، سجلات تدقيق، والتزام جاهز لـPDPL — مع OpenAI، Anthropic، Google، وأي نموذج مخصص.  
**AR — الزر:** اقرأ وثائق API ←

### Product 3: Compliance Scanner

**EN — Title:** PDPL & NCA ECC Gap Analysis in Minutes  
**EN — Description:** Upload your system prompt or sample conversations. Get a bilingual PDF report mapping findings to specific PDPL articles and NCA controls. Audit-ready.  
**EN — CTA:** Run a Free Scan →

**AR — العنوان:** تحليل الفجوات لـPDPL وضوابط NCA في دقائق  
**AR — الوصف:** ارفع system prompt أو عينة محادثات. احصل على تقرير PDF ثنائي اللغة يربط النتائج بمواد PDPL محددة وضوابط NCA. جاهز للتدقيق.  
**AR — الزر:** شغّل فحصاً مجانياً ←

### Product 4: Shield Generator

**EN — Title:** Auto-Harden Any System Prompt  
**EN — Description:** Paste a weak prompt. Get back a hardened version with explanations of every defense added. Includes Arabic-specific protections.  
**EN — CTA:** Harden a Prompt →

**AR — العنوان:** تقوية أي system prompt تلقائياً  
**AR — الوصف:** الصق prompt ضعيف. احصل على نسخة مقوّاة مع شرح كل دفاع تمت إضافته. تتضمن حماية خاصة بالعربية.  
**AR — الزر:** قوِّ prompt ←

### Product 5: Leaderboard

**EN — Title:** The Arabic Safety Index for Every Major LLM  
**EN — Description:** Daily-updated public ranking of Claude, GPT, Gemini, ALLaM, Jais, and more — scored on Arabic security, English security, PII protection, and more.  
**EN — CTA:** See Rankings →

**AR — العنوان:** مؤشر السلامة العربية لكل نموذج رئيسي  
**AR — الوصف:** ترتيب علني محدّث يومياً لـ Claude، GPT، Gemini، ALLaM، Jais، وغيرها — مع تقييم على الأمن العربي، الأمن الإنجليزي، حماية البيانات الشخصية.  
**AR — الزر:** شاهد الترتيب ←

### Product 6: CLI

**EN — Title:** `npx dir3 test` — Test Prompts From Your Terminal  
**EN — Description:** Open-source CLI for developers. Test, scan, and harden prompts from your terminal or CI/CD pipeline.  
**EN — CTA:** View on GitHub →

**AR — العنوان:** `npx dir3 test` — اختبر prompts من سطر الأوامر  
**AR — الوصف:** أداة CLI مفتوحة المصدر للمطورين. اختبر، افحص، وقوِّ prompts من terminal أو CI/CD.  
**AR — الزر:** شاهد على GitHub ←

---

## SECTION 4: FEATURES STRIP

| EN | AR |
|----|----|
| **Arabic-Native, Not Translated** | **عربي بالأصل، لا مترجم** |
| Built from the ground up for Arabic — not patched on top of English. | مبنية من الجذور للعربية — مش طبقة فوق إنجليزي. |
| **PDPL & NCA Ready** | **متوافق مع PDPL و NCA** |
| Compliance reports cite specific articles and controls. | تقارير الالتزام تستشهد بمواد وضوابط محددة. |
| **Bring Your Own Keys** | **استخدم مفاتيحك** |
| Your API keys never touch our servers. Privacy-first by design. | مفاتيحك ما تمر على سيرفراتنا. الخصوصية أولاً. |
| **Open-Core** | **Open-Core** |
| Detection engine and CLI are open source. Trust through transparency. | محرك الكشف وأداة CLI مفتوحة المصدر. الثقة عبر الشفافية. |

---

## SECTION 5: ATTACK CATEGORIES (Arabic-Specific Moat)

### EN Heading: Attacks No Other Tool Catches
### AR Heading: هجمات ما يكشفها أي أداة ثانية

**EN Body:** Most AI security tools miss attacks specific to Arabic. We built Dir3 to catch:
- **Diacritic Injection** — `تَجَاهَلْ التَّعْلِيْمَات` evades naive filters
- **Kashida Steganography** — `تـجـاهـل` hides commands with tatweel  
- **Religious Authority Spoofing** — false claims of being a sheikh, mufti, or religious official
- **Code-Switching Attacks** — mixing Arabic and English to slip through monolingual filters
- **Numeral Confusion** — mixing ٠١٢٣٤٥٦٧٨٩ with 0123456789
- **Dialect Manipulation** — switching between MSA and dialect mid-prompt

**AR Body:** أغلب أدوات أمن AI تفوّت هجمات خاصة بالعربية. بنينا Dir3 عشان نمسكها:
- **حقن التشكيل** — `تَجَاهَلْ التَّعْلِيْمَات` يتجاوز الفلاتر السطحية
- **إخفاء بالكشيدة** — `تـجـاهـل` يخفي أوامر بالتطويل
- **انتحال السلطة الدينية** — ادعاءات كاذبة بمنصب شيخ أو مفتٍ أو عالم ديني
- **هجمات تبديل اللغة** — مزج العربي والإنجليزي للهروب من فلاتر أحادية اللغة
- **الخلط بين الأرقام** — ٠١٢٣٤٥٦٧٨٩ مع 0123456789
- **التلاعب باللهجات** — التبديل بين الفصحى والعامية في منتصف الـprompt

---

## SECTION 6: PRICING

### EN Heading: Simple, Transparent Pricing
### AR Heading: تسعير واضح وبسيط

| Tier | EN | AR | Price |
|------|----|----|-------|
| **Free** | 10K proxy req/mo, public Playground, basic detection | ١٠ آلاف طلب/شهرياً، Playground علني، كشف أساسي | $0 |
| **Pro** | 1M proxy req/mo, full attack library, audit logs, email support | مليون طلب/شهرياً، مكتبة هجمات كاملة، سجلات تدقيق، دعم بالبريد | $499/mo |
| **Business** | 10M req/mo, custom rules, SSO, priority support | ١٠ ملايين طلب/شهرياً، قواعد مخصصة، SSO، دعم بأولوية | $2,499/mo |
| **Enterprise** | Unlimited, on-prem option, full PDPL audit, dedicated support | غير محدود، خيار on-prem، تدقيق PDPL كامل، دعم مخصص | Contact us / تواصل معنا |

---

## SECTION 7: TESTIMONIALS PLACEHOLDER

> _Placeholder until real testimonials are gathered post-launch_

### EN
> "Dir3 caught injection attacks our existing tools missed in Arabic. Setup took ten minutes."  
> — _CISO, [Saudi Bank — name TBA]_

> "The PDPL compliance reports made our annual audit dramatically easier."  
> — _Compliance Lead, [Saudi Telco — name TBA]_

### AR
> "درع مسك هجمات حقن ما لقتها أدواتنا الحالية بالعربي. الإعداد أخذ عشر دقائق."  
> — _مدير أمن المعلومات، [بنك سعودي — اسم لاحقاً]_

> "تقارير الالتزام بـPDPL سهّلت التدقيق السنوي بشكل كبير."  
> — _مسؤول الالتزام، [اتصالات سعودية — اسم لاحقاً]_

---

## SECTION 8: FAQ

### EN

**Q: Where is data hosted?**  
A: Production data is hosted in KSA-region servers wherever feasible. For Enterprise customers, on-premise deployment is available.

**Q: Do you store our system prompts?**  
A: Only if you save them in your account. Playground runs are anonymized by default. Proxy audit logs auto-redact PII.

**Q: Which LLMs do you support?**  
A: OpenAI (GPT-5, GPT-4.1, GPT-4o), Anthropic (Claude Opus 4.7, Sonnet 4.6, Haiku 4.5), Google (Gemini 2.5 Pro, Flash), Meta (Llama 4), Alibaba (Qwen 3), SDAIA (ALLaM-2), G42 (Jais), and any OpenAI-compatible endpoint.

**Q: Is the attack library open source?**  
A: ~70% is open source under Apache 2.0. The remaining 30% (Arabic-specific moat) is premium and requires a paid plan.

**Q: How does this differ from the LLM provider's built-in safety?**  
A: LLM providers' safety is generic and English-first. Dir3 adds Arabic-specific detection, KSA regulatory mapping, and audit trails — at the system prompt and infrastructure level, not just at the model level.

**Q: Do you offer on-premise deployment?**  
A: Yes, for Enterprise customers. Contact us for details.

### AR

**س: وين تتخزن البيانات؟**  
ج: البيانات في الإنتاج تُستضاف في سيرفرات بمنطقة المملكة قدر الإمكان. لعملاء Enterprise، النشر On-Premise متوفر.

**س: هل تخزّنون system prompts؟**  
ج: فقط إذا حفظتها في حسابك. تشغيلات Playground مجهولة الهوية افتراضياً. سجلات Proxy تنقّح PII تلقائياً.

**س: أي LLMs مدعومة؟**  
ج: OpenAI (GPT-5, GPT-4.1, GPT-4o)، Anthropic (Claude Opus 4.7, Sonnet 4.6, Haiku 4.5)، Google (Gemini 2.5 Pro, Flash)، Meta (Llama 4)، Alibaba (Qwen 3)، سدايا (ALLaM-2)، G42 (Jais)، وأي endpoint متوافق مع OpenAI.

**س: هل مكتبة الهجمات مفتوحة المصدر؟**  
ج: تقريباً ٧٠٪ مفتوحة المصدر تحت Apache 2.0. الـ٣٠٪ الباقية (الموat الخاص بالعربية) premium وتحتاج خطة مدفوعة.

**س: شو الفرق بين هذي والحماية المدمجة في الـLLM؟**  
ج: حماية الـLLM عامة وإنجليزية أولاً. درع يضيف كشف خاص بالعربية، ربط بالأنظمة السعودية، وسجلات تدقيق — على مستوى system prompt والبنية التحتية، مش بس على مستوى النموذج.

**س: هل تقدمون نشر On-Premise؟**  
ج: نعم، لعملاء Enterprise. تواصل معنا للتفاصيل.

---

## SECTION 9: FINAL CTA

### EN
**Heading:** Ship Your AI With Confidence  
**Body:** Join the platform built for the Arabic AI economy.  
**CTA Primary:** Start Free →  
**CTA Secondary:** Talk to Sales

### AR
**العنوان:** أطلق AI بثقة  
**النص:** انضم للمنصة المبنية لاقتصاد الذكاء الاصطناعي العربي.  
**الزر الرئيسي:** ابدأ مجاناً ←  
**الزر الثانوي:** تواصل مع المبيعات

---

## SECTION 10: FOOTER

### EN
- Product: Playground · Proxy · Scanner · Shield · Leaderboard · CLI
- Resources: Docs · API Reference · Attack Library · Blog · Status
- Company: About · Careers · Contact · Press
- Legal: Privacy · Terms · DPA · PDPL Compliance · Security
- Copyright: © 2026 Dir3. Built in Saudi Arabia 🇸🇦

### AR
- المنتج: Playground · Proxy · Scanner · Shield · Leaderboard · CLI
- الموارد: الوثائق · مرجع API · مكتبة الهجمات · المدونة · حالة الخدمة
- الشركة: من نحن · وظائف · تواصل · الإعلام
- قانوني: الخصوصية · الشروط · DPA · التزام PDPL · الأمن
- حقوق النشر: © ٢٠٢٦ درع. صُنع في السعودية 🇸🇦

---

## META TAGS / SEO

```html
<!-- English -->
<title>Dir3 — Arabic-Native AI Security Platform | PDPL & NCA Compliant</title>
<meta name="description" content="The first Arabic-native AI security platform. Runtime guardrails, prompt injection protection, PDPL/NCA ECC compliance, and red-team testing for LLMs in the Saudi market." />
<meta property="og:title" content="Dir3 — Arabic-Native AI Security" />
<meta property="og:description" content="Stop prompt injection. Pass PDPL audits. Built for the Saudi market." />
<meta property="og:image" content="https://dir3.ai/og-image.png" />

<!-- Arabic -->
<title>درع — منصة أمن الذكاء الاصطناعي العربية | متوافقة مع PDPL و NCA</title>
<meta name="description" content="أول منصة أمن ذكاء اصطناعي عربية بالكامل. حماية فورية، اكتشاف حقن التعليمات، التزام PDPL وضوابط NCA، واختبارات الاختراق للنماذج اللغوية في السوق السعودي." />
```
