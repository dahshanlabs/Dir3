# Dir3 — Technical Architecture

---

## 1. Stack Summary

| Layer | Choice | Rationale |
|-------|--------|-----------|
| Language | TypeScript 5.6+ | Type safety end-to-end |
| Monorepo | Turborepo + pnpm workspaces | Fast incremental builds, shared packages |
| Frontend | Next.js 15 (App Router) + React 19 | SSR, RSC, streaming, edge-ready |
| UI | TailwindCSS 4 + shadcn/ui + Radix | Production-grade components, RTL-friendly |
| i18n | next-intl | First-class App Router support, type-safe |
| Backend API | Hono on Node.js | Lighter than Express, edge-ready, OpenAPI types |
| ORM | Drizzle ORM | Type-safe, migration-friendly, low overhead |
| Database | PostgreSQL 16 | Default Replit option, JSONB for flexibility |
| Auth | Better Auth | Modern, plugin-based, magic link out of box |
| Background jobs | Inngest (free tier) or BullMQ + Redis | Leaderboard daily cron, async audit logs |
| LLM SDKs | @anthropic-ai/sdk, openai, @google/generative-ai | Official |
| PDF generation | @react-pdf/renderer | RTL Arabic support, React-based |
| Charts | Recharts | Lightweight, React-native |
| Validation | Zod | Single source of truth at API boundaries |
| Testing | Vitest + Playwright | Fast unit, real browser e2e |
| Linting | Biome | 10x faster than ESLint+Prettier |
| Deployment | Replit Reserved VM | Always-on, simple deploys |
| CDN/Cache | Cloudflare (free) in front | Static assets + DDoS protection |
| Email | Resend | Magic links, 3K/mo free |
| Error tracking | Sentry (free tier) | Production observability |
| Analytics | PostHog (self-hosted later) | Product analytics, no GDPR issues if EU traffic |

---

## 2. Repository Structure

```
dir3/
├── apps/
│   ├── web/                          # Main app — Playground, Scanner, Shield, Leaderboard, Dashboard
│   │   ├── src/app/
│   │   │   ├── [locale]/             # i18n root segment (ar, en)
│   │   │   │   ├── layout.tsx        # Root layout with RTL handling
│   │   │   │   ├── page.tsx          # Landing
│   │   │   │   ├── playground/
│   │   │   │   ├── scanner/
│   │   │   │   ├── shield/
│   │   │   │   ├── leaderboard/
│   │   │   │   ├── dashboard/
│   │   │   │   ├── pricing/
│   │   │   │   └── auth/
│   │   │   └── api/                  # Server-side routes
│   │   │       ├── playground/run/   # SSE streaming
│   │   │       ├── scanner/run/
│   │   │       ├── shield/generate/
│   │   │       └── leaderboard/data/
│   │   ├── src/components/
│   │   ├── src/lib/
│   │   ├── messages/                 # i18n strings
│   │   │   ├── ar.json
│   │   │   └── en.json
│   │   └── next.config.ts
│   │
│   ├── api/                          # Hono — Proxy API
│   │   ├── src/
│   │   │   ├── index.ts              # Hono app entry
│   │   │   ├── routes/
│   │   │   │   ├── v1-chat.ts        # OpenAI-compatible
│   │   │   │   ├── v1-messages.ts    # Anthropic-compatible
│   │   │   │   ├── v1-generate.ts    # Google AI-compatible
│   │   │   │   └── webhooks.ts
│   │   │   ├── middleware/
│   │   │   │   ├── auth.ts           # API key auth
│   │   │   │   ├── rate-limit.ts
│   │   │   │   └── logging.ts
│   │   │   └── upstream/             # Adapters per LLM provider
│   │   └── package.json
│   │
│   ├── docs/                         # Nextra-based docs site
│   └── landing/                      # (optional separate marketing site)
│
├── packages/
│   ├── core-engine/                  # ★ THE MOAT
│   │   ├── src/
│   │   │   ├── index.ts
│   │   │   ├── detect-injection.ts
│   │   │   ├── detect-pii.ts
│   │   │   ├── detect-toxicity.ts
│   │   │   ├── detect-topic-drift.ts
│   │   │   ├── unicode-checks.ts
│   │   │   ├── arabic-utils.ts       # Diacritic strip, kashida normalize, etc.
│   │   │   └── analyze.ts            # Top-level orchestrator
│   │   └── package.json
│   │
│   ├── attack-library/               # Loads + serves attack patterns
│   │   ├── src/index.ts
│   │   ├── data/attacks.json         # Imported from 07-attack-library.json
│   │   └── package.json
│   │
│   ├── compliance/                   # PDPL/NCA mapping
│   │   ├── src/
│   │   │   ├── pdpl-rules.ts
│   │   │   ├── nca-ecc-rules.ts
│   │   │   ├── analyze.ts
│   │   │   └── pdf-report.tsx
│   │   ├── data/
│   │   │   ├── pdpl-articles.json    # From 08-pdpl-articles.json
│   │   │   └── nca-ecc-controls.json # From 09-nca-ecc-controls.json
│   │   └── package.json
│   │
│   ├── shield-gen/                   # Prompt hardening
│   │   ├── src/
│   │   │   ├── harden.ts
│   │   │   └── domain-rules.ts
│   │   └── package.json
│   │
│   ├── ui/                           # Shared shadcn components
│   │   ├── src/
│   │   │   ├── button.tsx
│   │   │   ├── input.tsx
│   │   │   ├── locale-toggle.tsx
│   │   │   └── ... (30+ components)
│   │   └── tailwind.config.ts
│   │
│   ├── db/                           # Drizzle schema + migrations
│   │   ├── src/
│   │   │   ├── schema.ts
│   │   │   ├── client.ts
│   │   │   └── seed.ts
│   │   └── drizzle.config.ts
│   │
│   ├── cli/                          # npm package: dir3
│   │   ├── src/
│   │   │   ├── bin.ts                # Entry: #!/usr/bin/env node
│   │   │   ├── commands/
│   │   │   │   ├── test.ts
│   │   │   │   ├── scan.ts
│   │   │   │   ├── shield.ts
│   │   │   │   ├── check.ts
│   │   │   │   └── leaderboard.ts
│   │   │   └── config.ts
│   │   └── package.json              # bin: { "dir3": "./dist/bin.js" }
│   │
│   ├── shared-types/                 # Cross-package TypeScript types + Zod schemas
│   │   └── src/index.ts
│   │
│   └── llm-judges/                   # Reusable LLM judge prompts/calls
│       ├── src/
│       │   ├── injection-judge.ts
│       │   ├── topic-judge.ts
│       │   └── toxicity-judge.ts
│       └── prompts/                  # Loaded from 06-SYSTEM-PROMPTS.md
│
├── infra/
│   └── replit/
│       ├── replit.nix
│       └── .replit
│
├── docs/                             # This package — uploaded as Agent context
│   ├── 02-PRD-FULL.md
│   ├── 04-database-schema.sql
│   ├── 06-SYSTEM-PROMPTS.md
│   ├── 07-attack-library.json
│   ├── 08-pdpl-articles.json
│   └── 09-nca-ecc-controls.json
│
├── turbo.json
├── pnpm-workspace.yaml
├── package.json
├── biome.json
├── tsconfig.base.json
└── README.md
```

---

## 3. Data Flow Diagrams

### 3.1 Proxy Request Flow

```
[Customer App]
     │
     │ POST /v1/chat/completions
     │ Authorization: Bearer dir3_sk_xxx
     │ X-Dir3-Upstream-Provider: openai
     │ X-Dir3-Upstream-Key: sk-xxx
     ↓
[Dir3 Proxy — Hono]
     │
     ├─→ [Auth middleware] — validate dir3_sk, load org+key config
     │
     ├─→ [Pre-flight scan]
     │     ├─ Layer 1: regex/unicode (5ms)
     │     └─ Layer 2: semantic (200ms) — only if rules require it
     │
     │   ⮕ If BLOCKED: respond 400 with dir3_metadata
     │
     ├─→ [Forward to upstream]
     │     ├─ OpenAI / Anthropic / Google / Custom endpoint
     │     └─ Streaming or non-streaming
     │
     ├─→ [Post-flight scan]
     │     ├─ Layer 1: PII detection on response
     │     └─ Layer 2: topic-drift, toxicity (only if config says so)
     │
     │   ⮕ If FLAGGED: redact or replace response
     │
     ├─→ [Async log to audit_log] (PII-redacted version)
     │
     └─→ [Return to customer with dir3_metadata]
```

### 3.2 Playground Run Flow

```
[Browser]
   │
   │ POST /api/playground/run
   │ { systemPrompt, models[], byokKeys{}, attackCategories[] }
   ↓
[Next.js Route Handler — SSE]
   │
   ├─→ [Validate inputs with Zod]
   ├─→ [Save run record to DB, get run_id]
   │
   ├─→ FOR EACH model:
   │     │
   │     ├─→ FOR EACH attack in selected_attacks:
   │     │     │
   │     │     ├─→ Send `{system: systemPrompt, user: attack.payload}` to model
   │     │     │      (using user's BYOK key)
   │     │     │
   │     │     ├─→ Pass model's response to [Judge LLM]
   │     │     │      Judge prompt: "Did the attack succeed?"
   │     │     │
   │     │     ├─→ Score: { attack_id, model, succeeded, severity, explanation }
   │     │     │
   │     │     └─→ Stream score to browser via SSE
   │     │
   │     └─→ Aggregate per-model Hardness Score
   │
   ├─→ [Persist final results to DB]
   ├─→ [Generate shareable URL: /playground/r/{run_id}]
   └─→ [Close SSE]
```

---

## 4. RTL & Bilingual Architecture

### Detection in Layout
```tsx
// apps/web/src/app/[locale]/layout.tsx
export default function LocaleLayout({
  children,
  params: { locale }
}: {
  children: React.ReactNode;
  params: { locale: 'ar' | 'en' };
}) {
  const dir = locale === 'ar' ? 'rtl' : 'ltr';
  return (
    <html lang={locale} dir={dir}>
      <body className={dir === 'rtl' ? 'font-arabic' : 'font-sans'}>
        <NextIntlClientProvider>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
```

### Tailwind RTL utilities
- Use logical properties: `ms-4` (margin-start) instead of `ml-4`
- Use `pe-4` (padding-end) instead of `pr-4`
- Use `text-start`/`text-end` instead of `text-left`/`text-right`
- Use `start-0`/`end-0` instead of `left-0`/`right-0`
- Tailwind 4 supports these natively

### Fonts
- **Arabic:** IBM Plex Sans Arabic (Google Fonts) — modern, technical look
- **English:** Inter (default) or IBM Plex Sans
- Load both in root layout, swap based on locale

### URL structure
- `/en/playground` → English
- `/ar/playground` → Arabic with RTL
- Default locale auto-detected from `Accept-Language`, fallback to English (since target users are bilingual but technical content reads more naturally in English)

---

## 5. Authentication

Better Auth setup:
- Email + magic link only (no passwords initially)
- Session stored in HTTP-only cookie
- API keys are separate (not session-based) — issued from dashboard, used for Proxy

```typescript
// packages/db/src/schema.ts (auth tables)
import { pgTable, text, timestamp, boolean } from 'drizzle-orm/pg-core';

export const user = pgTable('user', {
  id: text('id').primaryKey(),
  email: text('email').unique().notNull(),
  emailVerified: boolean('email_verified').default(false),
  name: text('name'),
  createdAt: timestamp('created_at').defaultNow(),
});

export const session = pgTable('session', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => user.id),
  expiresAt: timestamp('expires_at').notNull(),
  token: text('token').unique().notNull(),
});
```

---

## 6. Detection Engine API

Public surface in `packages/core-engine`:

```typescript
// Top-level entry
export async function analyze(input: {
  text: string;
  context?: { systemPrompt?: string; previousMessages?: Message[] };
  options?: { 
    layers?: ('pattern' | 'semantic' | 'deep')[];
    categories?: DetectionCategory[];
    language?: 'ar' | 'en' | 'auto';
  };
}): Promise<AnalysisResult>;

// Individual detectors
export function detectPromptInjection(text: string, lang: Language): PatternResult;
export function detectPII(text: string): PIIResult;
export function detectArabicAnomalies(text: string): UnicodeResult;
export async function detectTopicDrift(prompt: string, response: string): Promise<DriftResult>;
export async function detectToxicity(text: string, lang: Language): Promise<ToxicityResult>;

// Utilities
export function stripDiacritics(text: string): string;
export function normalizeKashida(text: string): string;
export function detectScript(text: string): { rtl: number; ltr: number; mixed: boolean };
export function normalizeArabicNumerals(text: string, target: 'arabic' | 'western'): string;
```

---

## 7. Deployment

### Production
- **Replit Reserved VM (Pro)** — always-on, $20/mo
- **Postgres** via Replit's managed Postgres
- **Custom domain** via Replit's domain settings
- **Cloudflare** in front for DDoS + caching
- **Sentry** for error tracking
- **Resend** for transactional email

### Environment variables (Replit Secrets)
```
DATABASE_URL=
ANTHROPIC_API_KEY=
OPENAI_API_KEY=
GOOGLE_AI_API_KEY=
AUTH_SECRET=
RESEND_API_KEY=
SENTRY_DSN=
NEXT_PUBLIC_BASE_URL=
NEXT_PUBLIC_API_URL=
```

### Build commands (Replit)
```
# .replit
run = "pnpm dev"
[deployment]
build = "pnpm build"
run = "pnpm start"
deploymentTarget = "vm"

# .nix
{ pkgs }: {
  deps = [ pkgs.nodejs_20 pkgs.pnpm pkgs.postgresql ];
}
```

---

## 8. Performance Budget

| Metric | Target | Why |
|--------|--------|-----|
| Landing page LCP | < 1.5s | First impression matters |
| Playground TTI | < 2s | User wants to start fast |
| Proxy added latency | < 250ms p99 | Users won't tolerate slow proxies |
| Detection Layer 1 | < 5ms | Per-request overhead |
| Detection Layer 2 | < 200ms | Acceptable for security check |
| PDF generation | < 5s | Can show progress UI |
| Leaderboard daily run | < 60min | Cron tolerance |

---

## 9. Security Architecture

- **API keys** stored hashed (Argon2id) — only prefix shown in UI
- **BYOK keys in Playground** never persisted server-side; sent per-request only
- **Audit logs** auto-redact detected PII before write
- **Rate limiting** per Dir3 API key (Redis-backed; or Postgres for v1)
- **CSRF** handled by Better Auth
- **Content Security Policy** strict; no inline scripts
- **Database encryption at rest** via Replit Postgres default
- **Backups** daily pg_dump → S3 (or GitHub for v1)

---

## 10. Observability

- **Sentry** for errors (web + api)
- **Console structured logs** (pino) with correlation IDs
- **Database** of audit_log doubles as observability for proxy
- **Metrics** dashboard in `/dashboard/metrics` for ops (us)
- **Status page** at `status.dir3.ai` — manually updated for v1, automated later
